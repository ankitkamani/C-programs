#include<stdio.h>
#define PI 3.14 
void main(){

float r , circle;

printf("enter value of redious :- ");
scanf("%f",&r);

circle = PI * r * r;

printf("area of cirlce is :- %f",circle);
}