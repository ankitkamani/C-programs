#include<stdio.h>

void main(){

float L,B,C;

printf("enter value of Length");
scanf("%f",&L);

printf("enter value of Length");
scanf("%f",&B);

C = (0.5) * (L*B);
printf("area of rectangle is :-%f",C);

}