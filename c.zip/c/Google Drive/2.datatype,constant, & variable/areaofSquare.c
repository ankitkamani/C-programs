#include<stdio.h>

void main(){
    
    float s,square;

printf("enter value of square :- ");
scanf("%f",&s);

square = s*4;

printf("area of square is :- %f",square);

}