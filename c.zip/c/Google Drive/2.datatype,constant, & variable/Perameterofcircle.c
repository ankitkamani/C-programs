#include<stdio.h>
#define pi 3.14

void main(){

float r,cal;

printf("enter value of redious:-");
scanf("%f",&r);

cal = 2 * pi * r;

printf("perameter of circle is :-%f",cal);

}