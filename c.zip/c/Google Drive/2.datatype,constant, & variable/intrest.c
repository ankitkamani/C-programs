#include<stdio.h>

void main(){

float p,r,n,intrest;

printf("enter value of p = ");
scanf("%f",&p);

printf("enter value of r = ");
scanf("%f",&r);

printf("enter value of n = ");
scanf("%f",&n);

intrest = p*r*n /100;

printf("intrest is :- %f",intrest);


}