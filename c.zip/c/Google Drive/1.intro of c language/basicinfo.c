#include<stdio.h>

void main(){

printf("my name is ankit, now i'm in RNW");

}