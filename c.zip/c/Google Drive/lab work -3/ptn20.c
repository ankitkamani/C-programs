#include<stdio.h>

void main(){

    int i,j;
    char a = '|',b = '-';

    for (i = 5; i >=1; i--)
    {
        for (j = i; j <=5; j++)
        {
            
            if (j%2)
            {
                printf(" %c",b);
            }else{
                    printf(" %c",a);
            }
            
        }
        printf("\n");
    }
    

}