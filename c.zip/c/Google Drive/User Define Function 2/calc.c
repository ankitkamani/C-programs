/*1.WAP to create infinite calc using UDF, switch case and Loop.*/

#include<stdio.h>

void main(){




}

void sum(int a,int b){

 printf("sum of 2 value is %d =")

}