/*4.WAP to find peform addition of 1D array & store it into another.*/

#include<stdio.h>

void main(){

    int a[10],b[10],sum[10],i;

    printf("Enter array value of a = \n");
    for (i = 0; i < 10; i++)
    {
        scanf("%d",&a[i]);
    }

    printf("Enter array value of b = \n");
    for (i = 0; i < 10; i++)
    {
        scanf("%d",&b[i]);
    }

    printf("sum of 1d array\n")
    for (i = 0; i < 10; i++)
    {
        sum[i] = a[i] + b[i];
        printf("%d\n",sum[i]);
    }
    
    

}