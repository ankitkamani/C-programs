/*1.WAP to get & print 1D array of N elements.*/

#include<stdio.h>

void main(){

    int num,a[num],i;
    printf("enter array value...\n");
    scanf("%d",&num);

    printf("enter array index...\n");
    for (i = 0; i < num; i++)
    {
        scanf("%d",&a[i]);
        printf("\n");
    }

    printf("print array index value...");
    for (i = 0; i < num; i++)
    {
        printf("%d\n",a[i]);
    }
    
}