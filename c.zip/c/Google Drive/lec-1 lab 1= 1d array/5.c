/*5.WAP to find peform merging of 1D array & store it into another.*/

#include<stdio.h>

void main(){

    int a[10],b[11],merge[10],i,j;

     printf("Enter array value of a = \n");
    for (i = 0; i < 5; i++)
    {
        scanf("%d",&a[i]);
    }

    printf("Enter array value of b = \n");
    for (i = 0; i < 5; i++)
    {
        scanf("%d",&b[i]);
    }
 
    printf("Merge of 2 array...\n");
    for(i = 0; i < 5; i++)
        {
            merge[i] = a[i];
        }
    for (i = 0,j=5; j < 10 && i<5; i++,j++)
    {
        merge[j] = b[i];
    }

       
    for (i = 0; i < 10; i++)
    {
        printf("%d\n",merge[i]);
    }
    

}