#include <stdio.h>

void main()
{
    int arr[] = {10,20,30,40,50,60};

    int num;

    num = sizeof(arr);
    
    printf("size of array = %d", num);
  
}