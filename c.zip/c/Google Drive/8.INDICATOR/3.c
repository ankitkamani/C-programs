/*3. C program to reverse an array using pointers*/
#include<stdio.h>    
void main()  
{  
    int a[5], i, *ptr;  
  
    printf("Enter integer numbers\n");  
    for(i = 0; i < 5; i++)  
        scanf("%d", &a[i]);  
  
    ptr = &a[5 - 1];  
  
    printf("\nElements of array in reverse order ...\n");  
    for(i = 0; i < 5; i++)  
        printf("%d\n", *ptr--);  
  
}  