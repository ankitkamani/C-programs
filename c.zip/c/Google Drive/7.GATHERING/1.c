/*1. C program to find factorial of number using recursion.*/

#include<stdio.h>

int fac(int n);
void main() {
    int n;
    printf("Enter a Number: ");
    scanf("%d",&n);
    printf("Factorial of %d = %d", n, fac(n));
}

int fac(int n) {
    if (n>=1)
        return n*fac(n-1);
    else
        return 1;
}