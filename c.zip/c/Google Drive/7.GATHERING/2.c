/*2. C program to find Sum of all Array Elements by passing array as an argument using User Define Functions.*/

#include <stdio.h>

void main()
{
    int i, n,arr[n];

    printf("Enter size of the array: ");
    scanf("%d", &n);

    printf("Enter elements in the array: \n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("Sum of all elements of array = %d", sop(n,arr));

}
int sop( int n ,int ar[])
{
    int i,sum=0;

    for (i = 0; i < n; i++)
    {
        sum += ar [i];
    }
    return sum;
}