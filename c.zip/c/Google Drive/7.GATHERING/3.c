/*3. C program to find Length of the String by passing String/ Character Array as an Argument using User Define Functions.*/

#include <stdio.h>
#include <string.h>

int len(char s);
void main()
{
    char s[100];
    printf("enter any string = ");
    scanf("%s", &s);
    len(s);
}
int len(char s)
{
    int i;

    i = strlen(s);
    printf("Length of the string: %d", i);
}