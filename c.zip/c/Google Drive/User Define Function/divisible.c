/*2.WAP to find if a given nunmber is divisible by 3 & 5 both or not, using UDF.*/

#include <stdio.h>

void main()
{
    int n;

    printf("enter number = ");
    scanf("%d", &n);
    a(n);
}

void a(int num)
{

    if (num % 3 == 0 && num % 5==0 )
    {
        printf("Number is divisible by 3 & 5.");
    }
    else
    {
        printf("Number is not divisible by 3 & 5.");
    }
}