/*1.WAP to find cube of given no using UDF.*/

#include<stdio.h>

void main(){

int n;
printf("enter number = ");
scanf("%d",&n);

fnc(n);

}


void fnc(int num){

    printf("Cube of %d is = %d",num,num*num*num);

}