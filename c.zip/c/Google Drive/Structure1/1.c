#include<stdio.h>

struct stu
{
    int stu_id;
    char stu_name[20];
    int stu_age;
    char stu_course[30];
    char stu_city[20];
    int stu_std;
    char stu_school[20];
};

void main(){

    struct stu s;

    printf("enter stu_id :-");
    scanf("%d",&s.stu_id);

    printf("enter stu_name :-");
    scanf("%s",&s.stu_name);

    printf("enter stu_age :-");
    scanf("%d",&s.stu_age);

    printf("enter stu_course :-");
    scanf("%s",&s.stu_course);

    printf("enter stu_city :-");
    scanf("%s",&s.stu_city);

    printf("enter stu_std :-");
    scanf("%d",&s.stu_std);

    printf("enter stu_school :-");
    scanf("%s",&s.stu_school);



    printf("stu_id :- %d\n",s.stu_id);
    printf("stu_name :- %s\n",s.stu_name);
    printf("stu_age :- %d\n",s.stu_age);
    printf("stu_course :- %s\n",s.stu_course);
    printf("stu_city :- %s\n",s.stu_city);
    printf("stu_std :- %d\n",s.stu_std);
    printf("stu_school :- %s\n",s.stu_school);


}