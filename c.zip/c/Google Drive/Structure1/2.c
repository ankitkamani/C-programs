#include<stdio.h>

struct emp
{
    int emp_id;
    char emp_name[20];
    int emp_age;
    char emp_role[30];
    char emp_city[20];
    char emp_experience[20];
    int emp_company_name[20];

};

void main(){

    struct emp s;

    printf("enter emp_id :-");
    scanf("%d",&s.emp_id);

    printf("enter emp_name :-");
    scanf("%s",&s.emp_name);

    printf("enter emp_age :-");
    scanf("%d",&s.emp_age);

    printf("enter emp_role :-");
    scanf("%s",&s.emp_role);

    printf("enter emp_city :-");
    scanf("%s",&s.emp_city);

    printf("enter emp_experience :-");
    scanf("%s",&s.emp_experience);

    printf("enter emp_company_name :-");
    scanf("%s",&s.emp_company_name);



    printf("emp_id :- %d\n",s.emp_id);
    printf("emp_name :- %s\n",s.emp_name);
    printf("emp_age :- %d\n",s.emp_age);
    printf("emp_role :- %s\n",s.emp_role);
    printf("emp_city :- %s\n",s.emp_city);
    printf("emp_experience :- %s\n",s.emp_experience);
    printf("emp_company_name :- %s\n",s.emp_company_name);


}