#include<stdio.h>

void main(){

    int check;

    printf("Enter number :-");
    scanf("%d",&check);

    (check%2==0)?printf("It is Even Number"):printf("It is Odd Number");

}