
#include<stdio.h>

void main(){
    printf("\n\t*\t*\t*\t*\t*\t*\t*\n\n*\t*\t*\t*\t*\t*\t*\t*\n*\t\t*\t\t\t\t\t*\n*\t\t*\t\t*\t*\t*\t*\n*\t\t*\t\t*\t\t*\t*\n*\t*\t*\t*\t*\t*\t*\t*");
}