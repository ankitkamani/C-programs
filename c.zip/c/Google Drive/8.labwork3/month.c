#include <stdio.h>

void main()
{

    int month;

    printf("enter month number:-");
    scanf("%d", &month);

    switch (month)
    {
    case 'j':
    case 'j':
        printf("January");
        break;

    case 'F':
    case 'f':
        printf("February");
        break;

    case 'R':
    case 'r':
        printf("March");
        break;

    case 'p':
    case 'P':
        printf("April");
        break;

    case 'y':
    case 'Y':
        printf("May");
        break;

    case 'U':
    case 'u':
        printf("June");
        break;

    case 'L':
    case 'l':
        printf("July");
        break;

    case 'a':
    case 'A':
        printf("August");
        break;

    case 'S':
    case 's':
        printf("September");
        break;

    case 'o':
    case 'O':
        printf("October");
        break;

    case 'n':
    case 'N':
        printf("November");
        break;

    case 'd':
    case 'D':
        printf("December");
        break;

    default:
        printf("not valid number...");
        break;
    }
}