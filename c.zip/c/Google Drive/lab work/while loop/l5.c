/*WAP to print odd no. from 1 to N using do while loop.*/

#include<stdio.h>

void main(){

    int i=1,number;

    printf("enter number = ");
    scanf("%d",&number);

    while (i<=number)
    {
        if (i%2)
        {
            printf("%d\n",i);
        }
    
        i++;
    }
}