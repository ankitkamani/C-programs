/*WAP to Print 1 to 10 using do while loop.*/

#include<stdio.h>

void main(){

    int i=1;

    while (i<=10)
    {
        printf("%d\n",i);
        i++;
    }


}
