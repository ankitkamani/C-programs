/*WAP to print sum 1 to N using do while loop.*/

#include<stdio.h>

void main(){

    int i=1,num,sum=0;

    printf("enter number = ");
    scanf("%d",&num);

    while (i<=num)
    {
        sum +=i;
        i++;
    }
    printf("sum is = %d",sum);

}