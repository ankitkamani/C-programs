/*WAP to calculate the factorial of N. using do while loop.*/

#include<stdio.h>

void main(){

    int i=1,number,fact=1;

    printf("enter number = ");
    scanf("%d",&number);

    while (i<=number)
    {
        fact = fact*i;
        i++;
    }
    printf("factorial of number is :- %d",fact);
    

}