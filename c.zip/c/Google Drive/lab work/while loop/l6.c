/*WAP to print even no. from N to 1 using do while loop.*/

#include<stdio.h>

void main(){

    int i=1,number;

    printf("enter number = ");
    scanf("%d",&number);

    while (number>=i)
    {
        if (number%2==0)
        {
            printf("%d\n",number);
        }
    
        number--;
    }
}