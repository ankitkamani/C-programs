/*WAP to print N to 1 using do while loop.*/

#include<stdio.h>

void main(){

    int i=1,number;

    printf("enter number = ");
    scanf("%d",&number);

    while (number>=i)
    {
        printf("%d\n",number);
        number--;
    }
    

}