/*WAP to print 10 to 1 using do while loop.*/

#include<stdio.h>

void main(){

    int i=10;

    while (i>=1)
    {
        printf("%d\n",i);
        i--;
    }
    


}