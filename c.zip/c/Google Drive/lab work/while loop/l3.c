/*WAP to print 1 to N using do while loop.*/

#include<stdio.h>

void main(){

    int i=1,number;

    printf("enter number = ");
    scanf("%d",&number);

    while (i<=number)
    {
        printf("%d\n",i);
        i++;
    }
    

}
