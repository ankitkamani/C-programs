/*WAP to print thr multiplication table of N using do while loop.*/

#include<stdio.h>

void main(){

    int i=1,number,mul=1;

    printf("enter number = ");
    scanf("%d",&number);

    while (i<=10)
    {
        mul = i*number;
         printf("%d * %d = %d\n",number,i,mul);
        i++;
    }
   

}