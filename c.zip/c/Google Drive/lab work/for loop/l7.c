/*WAP to Find leap year from 2000 to 3000 using for loop.*/

#include<stdio.h>

void main(){

    int y1=2000,y2=3000;

for (y1; y1<=y2; y1++)
{
    if (y1%4==0)
        {
            printf("%d\n",y1);
        }
        y1++;
}


}