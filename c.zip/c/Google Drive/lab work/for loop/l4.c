/*WAP to print N to 1 using for loop.*/

#include<stdio.h>

void main(){

    int i=1,number;
    printf("enter number =");
    scanf("%d",&number);

    for (number; number>=i; number--)
    {
         printf("%d\n",number);
    }
    


}