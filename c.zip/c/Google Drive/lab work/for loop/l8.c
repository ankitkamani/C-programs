/*WAP to print sum 1 to N using for loop.*/

#include<stdio.h>

void main(){

    int i=1,num,sum=0;

    printf("enter number = ");
    scanf("%d",&num);

    for (i; i <= num; i++)
    {
        sum +=i;
        
    }
     printf("sum is = %d",sum);

}