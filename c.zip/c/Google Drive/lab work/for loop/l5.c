/*WAP to print odd no. from 1 to N using for loop.*/

#include<stdio.h>

void main(){

    int i=1,number;

    printf("enter number = ");
    scanf("%d",&number);

    for (i; i <=number; i++)
    {
        if (i%2)
        {
            printf("%d\n",i);
        }
    }
}