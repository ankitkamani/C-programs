/*WAP to print thr multiplication table of N using for loop.*/

#include<stdio.h>

void main(){

    int i=1,number,mul=1;

    printf("enter number = ");
    scanf("%d",&number);

for (i ; i <=10; i++)
    {
        mul = i*number;
         printf("%d * %d = %d\n",number,i,mul);
    }
   

}