#include<stdio.h>

void main(){

printf("\t*\t\t*\n*\t\t*\n\t*\t\t*");

}