#include<stdio.h>

void main(){

    float d,f;

printf("Enter celsius :- ");
scanf("%f",&d);

f = d*9/5+32;

printf("fahrenheit :- %f",f);

}