#include<stdio.h>
#include<conio.h>

void main(){

int a=10;
int b=20;
int c=30;
int sum;

clrscr();

sum = a+b+c;

printf("sum of three int numbers : %d",sum);
}