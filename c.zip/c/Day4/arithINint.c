#include<stdio.h>

void main(){

int a,b,c;

printf("sum of two number :");

printf("Enter first number :-");
scanf("%d",&a);

printf("Enter first number :-");
scanf("%d",&b);

c = a+b;
printf("sum of two number is :-%d",c);


printf("substraction of two number :");

printf("Enter first number :-");
scanf("%d",&a);

printf("Enter first number :-");
scanf("%d",&b);

c = a-b;
printf("substraction of two number is :-%d",c);


printf("multipication of two number :");

printf("Enter first number :-");
scanf("%d",&a);

printf("Enter first number :-");
scanf("%d",&b);

c = a*b;
printf("multipication of two number is :-%d",c);


printf("divisiom of two number :");

printf("Enter first number :-");
scanf("%d",&a);

printf("Enter first number :-");
scanf("%d",&b);

c = a/b;
printf("divisiom of two number is :-%d",c);


}