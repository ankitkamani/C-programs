#include<stdio.h>

void main(){

float a,b,c;

printf("sum of two number :");

printf("Enter first number :-");
scanf("%f",&a);

printf("Enter second number :-");
scanf("%f",&b);

c = a+b;
printf("sum of two number is :-%f",c);


printf("substraction of two number :");

printf("Enter first number :-");
scanf("%f",&a);

printf("Enter second number :-");
scanf("%f",&b);

c = a-b;
printf("substraction of two number is :-%f",c);


printf("multipication of two number :");

printf("Enter first number :-");
scanf("%f",&a);

printf("Enter second number :-");
scanf("%f",&b);

c = a*b;
printf("multipication of two number is :-%f",c);


printf("divisiom of two number :");

printf("Enter first number :-");
scanf("%f",&a);

printf("Enter second number :-");
scanf("%f",&b);

c = a/b;
printf("divisiom of two number is :-%f",c);


}