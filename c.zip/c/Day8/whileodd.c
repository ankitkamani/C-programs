#include<stdio.h>

void main(){

    int a;

    a=1;
    while (a<=10)
    {
        if (a%2==1)
        {
            printf("%d\n",a);
        }
        a++;
    }
    

}