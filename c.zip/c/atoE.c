#include <stdio.h>

void main()
{

    char c;

    printf("enter a/A to z/Z = ");
    c = getche();

    printf("\n");
    if (c == 'A' || c == 'a')
    {
        printf("A for Apple...");
    }
    else if (c == 'B' || c == 'b')
    {
        printf("B for Ball...");
    }
    else if (c == 'C' || c == 'c')
    {
        printf("C for Cat...");
    }
    else if (c == 'D' || c == 'd')
    {
        printf("D for Dog...");
    }
    else if (c == 'E' || c == 'e')
    {
        printf("E for eye...");
    }
    else
    {
        printf("Enter proper input...");
    }
}
