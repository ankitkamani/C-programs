#include<stdio.h>
#include<conio.h>

void main(){

float a = 10.6;
float b = 20.4;
float c = 30.10;
float sum;

clrscr();
sum = a+b+c;

printf("sum of three flote number : %f",sum);

}