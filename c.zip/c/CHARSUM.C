#include<stdio.h>

void main(){

char a ='a';
char b ='b';
char c = 'c';

printf("sum of three char value : %c%c%c",a,b,c);

}